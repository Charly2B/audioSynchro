// SubtitleExtractor.swift
import Foundation

// MARK: - Modèle

struct SubtitleEntry: Identifiable {
    let id: Int          // numéro SRT (1-based, unique dans le fichier)
    let timecode: String // "00:00:01,000 --> 00:00:03,500"
    var text: String
}

// MARK: - Erreurs

enum SubtitleError: LocalizedError {
    case aucuneSousTitre
    case parseFailed

    var errorDescription: String? {
        switch self {
        case .aucuneSousTitre:
            return "Aucune piste de sous-titres (texte) trouvée dans la vidéo EN. Les sous-titres image (PGS/VOBSUB) ne sont pas supportés."
        case .parseFailed:
            return "Impossible de lire le fichier SRT extrait."
        }
    }
}

// MARK: - Extracteur

final class SubtitleExtractor {

    // MARK: Extraction via ffmpeg → SRT

    static func extract(from videoURL: URL, ffmpegPath: String) async throws -> [SubtitleEntry] {
        let tmpSRT = FileManager.default.temporaryDirectory
            .appendingPathComponent("audiosync_subs_\(Int(Date().timeIntervalSince1970)).srt")
        defer { try? FileManager.default.removeItem(at: tmpSRT) }

        // Extrait la première piste sous-titres texte en format SRT
        try await runFFmpeg(ffmpegPath, arguments: [
            "-i", videoURL.path,
            "-map", "0:s:0",
            "-c:s", "srt",
            "-y",
            tmpSRT.path
        ])

        guard let content = try? String(contentsOf: tmpSRT, encoding: .utf8) else {
            throw SubtitleError.parseFailed
        }

        let entries = parseSRT(content)
        guard !entries.isEmpty else { throw SubtitleError.aucuneSousTitre }
        return entries
    }

    // MARK: Sérialise en SRT

    static func toSRT(_ entries: [SubtitleEntry]) -> String {
        entries.map { "\($0.id)\n\($0.timecode)\n\($0.text)\n" }
               .joined(separator: "\n")
    }

    // MARK: Parseur SRT

    static func parseSRT(_ content: String) -> [SubtitleEntry] {
        let normalized = content
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")

        return normalized
            .components(separatedBy: "\n\n")
            .compactMap { block -> SubtitleEntry? in
                let lines = block.components(separatedBy: "\n").filter { !$0.isEmpty }
                guard lines.count >= 3,
                      let idx = Int(lines[0].trimmingCharacters(in: .whitespaces)),
                      lines[1].contains("-->") else { return nil }
                let text = lines.dropFirst(2).joined(separator: "\n")
                return SubtitleEntry(id: idx, timecode: lines[1], text: text)
            }
    }

    // MARK: Process helper

    static func runFFmpeg(_ path: String, arguments: [String]) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            let p = Process()
            p.executableURL = URL(fileURLWithPath: path)
            p.arguments = arguments
            p.standardOutput = FileHandle.nullDevice
            let errPipe = Pipe()
            p.standardError = errPipe
            p.terminationHandler = { proc in
                if proc.terminationStatus == 0 {
                    cont.resume()
                } else {
                    let raw = String(data: errPipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8) ?? ""
                    let msg = raw.components(separatedBy: "\n").last(where: { !$0.isEmpty }) ?? "erreur inconnue"
                    cont.resume(throwing: NSError(
                        domain: "SubtitleExtractor", code: Int(proc.terminationStatus),
                        userInfo: [NSLocalizedDescriptionKey: "ffmpeg sous-titres : \(msg)"]
                    ))
                }
            }
            do { try p.run() } catch { cont.resume(throwing: error) }
        }
    }
}
