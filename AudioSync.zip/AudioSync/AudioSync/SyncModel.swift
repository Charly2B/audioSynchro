import Foundation
import AVFoundation
import Combine
import SwiftUI

@MainActor
final class SyncModel: ObservableObject {

    // MARK: - Fichiers

    @Published var videoEN: URL? = nil   // vidéo anglaise (fournit vidéo + audio référence)
    @Published var videoFR: URL? = nil   // vidéo française (on prend seulement sa piste audio)

    // MARK: - Résultats

    @Published var offsetSeconds: Double = 0
    @Published var confidence: Double    = 0
    @Published var outputURL: URL?       = nil

    // MARK: - État

    enum Step { case idle, extracting, aligning, mixing, done, error(String) }
    @Published var step:     Step   = .idle
    @Published var progress: Double = 0
    @Published var log:      String = ""

    var isProcessing: Bool {
        switch step {
        case .extracting, .aligning, .mixing: return true
        default: return false
        }
    }

    // MARK: - Pipeline principal

    func run(outputURL destURL: URL) async {
        guard let en = videoEN, let fr = videoFR else { return }

        let tempDir = destURL.deletingLastPathComponent()

        do {
            // 0. Extraction audio → m4a propre (utilisé pour cross-corr ET pour le mix)
            step = .extracting
            let prepEN = try await prepareURL(en, label: "EN", tempDir: tempDir)
            let prepFR = try await prepareURL(fr, label: "FR", tempDir: tempDir)
            defer {
                // supprime les temp audio après le mix
                if prepEN != en { try? FileManager.default.removeItem(at: prepEN) }
                if prepFR != fr { try? FileManager.default.removeItem(at: prepFR) }
            }

            // 1. Extraction audio
            log = "Extraction audio EN…"
            progress = 0.1
            let samplesEN = try await AudioAligner.extractAudio(from: prepEN)

            log = "Extraction audio FR…"
            progress = 0.25
            let samplesFR = try await AudioAligner.extractAudio(from: prepFR)

            // 2. Alignement par cross-correlation
            step = .aligning
            log = "Calcul de l'alignement…"
            progress = 0.45
            let result = await Task.detached(priority: .userInitiated) {
                AudioAligner.findOffset(reference: samplesEN, toAlign: samplesFR)
            }.value

            offsetSeconds = result.offsetSeconds
            confidence    = result.confidence
            log = String(format: "Offset détecté : %.3f s (confiance : %.0f%%)", result.offsetSeconds, result.confidence * 100)
            progress = 0.6

            // 3. Mix : vidéo originale EN + audio m4a FR (évite les problèmes de codec MKV)
            step = .mixing
            log = "Mixage en cours…"

            _ = try await VideoMixer.mix(
                videoEN: en,
                audioFR: fr,
                offsetSeconds: result.offsetSeconds,
                outputURL: destURL
            ) { [weak self] p in
                Task { @MainActor [weak self] in
                    self?.progress = 0.6 + p * 0.4
                }
            }

            outputURL = destURL
            step      = .done
            progress  = 1.0
            log       = "✅ Terminé — vidéo prête à exporter"

        } catch {
            step = .error(error.localizedDescription)
            log  = "❌ \(error.localizedDescription)"
        }
    }

    /// Ajustement manuel de l'offset (si l'auto n'est pas parfait)
    func applyManualOffset(_ offset: Double, outputURL destURL: URL) async {
        guard let en = videoEN, let fr = videoFR else { return }
        step = .mixing
        progress = 0
        log = "Application de l'offset manuel…"
        offsetSeconds = offset
        let tempDir = destURL.deletingLastPathComponent()
        do {
            let prepEN = try await prepareURL(en, label: "EN", tempDir: tempDir)
            let prepFR = try await prepareURL(fr, label: "FR", tempDir: tempDir)
            defer {
                if prepEN != en { try? FileManager.default.removeItem(at: prepEN) }
                if prepFR != fr { try? FileManager.default.removeItem(at: prepFR) }
            }
            _ = try await VideoMixer.mix(videoEN: en, audioFR: fr, offsetSeconds: offset, outputURL: destURL) { [weak self] p in
                Task { @MainActor [weak self] in self?.progress = p }
            }
            outputURL = destURL
            step = .done
            log  = "✅ Offset manuel appliqué"
        } catch {
            step = .error(error.localizedDescription)
            log  = "❌ \(error.localizedDescription)"
        }
    }

    func reset() {
        videoEN = nil; videoFR = nil
        outputURL = nil; step = .idle
        progress = 0; log = ""
        offsetSeconds = 0; confidence = 0
    }

    // MARK: - Remuxage MKV → MP4 (via ffmpeg, sans ré-encodage)

    private func prepareURL(_ url: URL, label: String, tempDir: URL? = nil) async throws -> URL {
        guard url.pathExtension.lowercased() == "mkv" else { return url }

        log = "Remuxage \(label) (MKV → MP4)…"

        let ffmpeg = ffmpegPath()
        guard let ffmpeg else {
            throw NSError(domain: "AudioSync", code: 2, userInfo: [
                NSLocalizedDescriptionKey: "ffmpeg introuvable. Installe-le via Homebrew : brew install ffmpeg"
            ])
        }

        let dir = tempDir ?? FileManager.default.temporaryDirectory
        let tmp = dir.appendingPathComponent(".\(label)_audio_\(Int(Date().timeIntervalSince1970)).m4a")
        try? FileManager.default.removeItem(at: tmp)

        // Extrait uniquement l'audio (pas de vidéo) → beaucoup plus rapide
        try await runProcess(ffmpeg, arguments: [
            "-i", url.path,
            "-vn",                // pas de vidéo
            "-map", "0:a:0",      // première piste audio
            "-c:a", "aac",        // audio converti en AAC (compatible AVFoundation)
            "-ac", "2",           // force stéréo
            "-ar", "48000",       // sample rate explicite
            "-map_metadata", "-1",
            "-y",
            tmp.path
        ])

        return tmp
    }

    private func ffmpegPath() -> String? {
        let candidates = [
            "/opt/homebrew/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
            "/usr/local/Cellar/ffmpeg/8.0.1/bin/ffmpeg",
            "/usr/bin/ffmpeg"
        ]
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
    }

    private func runProcess(_ executable: String, arguments: [String]) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            let process = Process()
            process.executableURL = URL(fileURLWithPath: executable)
            process.arguments = arguments
            process.standardOutput = FileHandle.nullDevice

            let stderrPipe = Pipe()
            process.standardError = stderrPipe

            process.terminationHandler = { p in
                let errOutput = String(data: stderrPipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8) ?? ""
                if p.terminationStatus == 0 {
                    continuation.resume()
                } else {
                    let detail = errOutput.components(separatedBy: "\n").last(where: { !$0.isEmpty }) ?? ""
                    continuation.resume(throwing: NSError(
                        domain: "AudioSync", code: Int(p.terminationStatus),
                        userInfo: [NSLocalizedDescriptionKey: "ffmpeg erreur : \(detail)"]
                    ))
                }
            }
            do {
                try process.run()
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}
