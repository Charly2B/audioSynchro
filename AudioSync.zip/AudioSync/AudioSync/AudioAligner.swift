import Foundation
import AVFoundation
import Accelerate

// MARK: - AudioAligner
// Trouve automatiquement l'offset entre deux pistes audio par cross-correlation FFT (O(n log n))

final class AudioAligner {

    struct AlignmentResult {
        let offsetSeconds: Double   // décalage à appliquer à la piste FR (positif = retarder, négatif = avancer)
        let confidence: Double      // 0-1, fiabilité de la détection
    }

    // MARK: - Extraction PCM

    /// Extrait les samples PCM mono 8kHz — résolution suffisante, calcul plus léger
    static func extractAudio(from url: URL, maxDuration: Double = 60) async throws -> [Float] {
        let asset = AVAsset(url: url)
        let audioTracks = try await asset.loadTracks(withMediaType: .audio)
        guard !audioTracks.isEmpty else {
            throw NSError(domain: "AudioSync", code: 1, userInfo: [NSLocalizedDescriptionKey: "Aucune piste audio"])
        }

        let reader = try AVAssetReader(asset: asset)
        let settings: [String: Any] = [
            AVFormatIDKey:               kAudioFormatLinearPCM,
            AVSampleRateKey:             8000.0,
            AVNumberOfChannelsKey:       1,
            AVLinearPCMBitDepthKey:      32,
            AVLinearPCMIsFloatKey:       true,
            AVLinearPCMIsNonInterleaved: false
        ]
        let output = AVAssetReaderAudioMixOutput(audioTracks: audioTracks, audioSettings: settings)
        output.alwaysCopiesSampleData = false
        reader.add(output)
        reader.startReading()

        var samples: [Float] = []
        let maxSamples = Int(maxDuration * 8000)

        while reader.status == .reading && samples.count < maxSamples {
            guard let buf = output.copyNextSampleBuffer(),
                  let block = CMSampleBufferGetDataBuffer(buf) else { break }
            let length = CMBlockBufferGetDataLength(block)
            var data = [Float](repeating: 0, count: length / 4)
            CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: length, destination: &data)
            samples.append(contentsOf: data)
        }
        reader.cancelReading()
        return samples
    }

    // MARK: - Cross-correlation via FFT (O(n log n))

    /// Calcule l'offset en secondes entre deux pistes audio
    nonisolated static func findOffset(reference: [Float], toAlign: [Float], sampleRate: Double = 8000) -> AlignmentResult {
        let n = min(reference.count, toAlign.count)
        guard n > 0 else { return AlignmentResult(offsetSeconds: 0, confidence: 0) }

        let ref = normalize(Array(reference.prefix(n)))
        let aln = normalize(Array(toAlign.prefix(n)))

        // Taille FFT = prochaine puissance de 2 >= 2n (évite l'aliasing circulaire)
        let log2n = Int(ceil(log2(Double(n * 2))))
        let fftSize = 1 << log2n

        guard let setup = vDSP_create_fftsetup(vDSP_Length(log2n), FFTRadix(kFFTRadix2)) else {
            return AlignmentResult(offsetSeconds: 0, confidence: 0)
        }
        defer { vDSP_destroy_fftsetup(setup) }

        // Padding
        var refPad = ref + [Float](repeating: 0, count: fftSize - n)
        var alnPad = aln + [Float](repeating: 0, count: fftSize - n)
        var refImag = [Float](repeating: 0, count: fftSize)
        var alnImag = [Float](repeating: 0, count: fftSize)

        let corr: [Float] = refPad.withUnsafeMutableBufferPointer { rRealBuf in
            alnPad.withUnsafeMutableBufferPointer { aRealBuf in
                refImag.withUnsafeMutableBufferPointer { rImagBuf in
                    alnImag.withUnsafeMutableBufferPointer { aImagBuf in

                        var rSplit = DSPSplitComplex(realp: rRealBuf.baseAddress!, imagp: rImagBuf.baseAddress!)
                        var aSplit = DSPSplitComplex(realp: aRealBuf.baseAddress!, imagp: aImagBuf.baseAddress!)

                        // FFT des deux signaux
                        vDSP_fft_zip(setup, &rSplit, 1, vDSP_Length(log2n), FFTDirection(FFT_FORWARD))
                        vDSP_fft_zip(setup, &aSplit, 1, vDSP_Length(log2n), FFTDirection(FFT_FORWARD))

                        // Multiplication : ref_fft * conj(aln_fft)
                        var outReal = [Float](repeating: 0, count: fftSize)
                        var outImag = [Float](repeating: 0, count: fftSize)
                        return outReal.withUnsafeMutableBufferPointer { oRealBuf in
                            outImag.withUnsafeMutableBufferPointer { oImagBuf in
                                var oSplit = DSPSplitComplex(realp: oRealBuf.baseAddress!, imagp: oImagBuf.baseAddress!)
                                vDSP_zvmul(&rSplit, 1, &aSplit, 1, &oSplit, 1, vDSP_Length(fftSize), -1)

                                // IFFT
                                vDSP_fft_zip(setup, &oSplit, 1, vDSP_Length(log2n), FFTDirection(FFT_INVERSE))

                                // Normalisation
                                var scale = 1.0 / Float(fftSize)
                                vDSP_vsmul(oRealBuf.baseAddress!, 1, &scale, oRealBuf.baseAddress!, 1, vDSP_Length(fftSize))
                                return Array(oRealBuf)
                            }
                        }
                    }
                }
            }
        }

        // Pic de corrélation
        var maxVal: Float = 0
        var maxIdx: vDSP_Length = 0
        vDSP_maxvi(corr, 1, &maxVal, &maxIdx, vDSP_Length(fftSize))

        // Offset circulaire : indices > fftSize/2 correspondent à des offsets négatifs
        let idx = Int(maxIdx)
        let offsetSamples = idx <= fftSize / 2 ? idx : idx - fftSize
        let offsetSeconds  = Double(-offsetSamples) / sampleRate

        let maxCorr = corr.max() ?? 1
        let confidence = Double(maxVal / max(maxCorr, 1e-6))

        return AlignmentResult(offsetSeconds: offsetSeconds, confidence: confidence)
    }

    private static func normalize(_ samples: [Float]) -> [Float] {
        var result = samples
        var mean: Float = 0
        vDSP_meanv(samples, 1, &mean, vDSP_Length(samples.count))
        var negMean = -mean
        vDSP_vsadd(result, 1, &negMean, &result, 1, vDSP_Length(result.count))
        var rms: Float = 0
        vDSP_rmsqv(result, 1, &rms, vDSP_Length(result.count))
        if rms > 0 {
            var invRms = 1.0 / rms
            vDSP_vsmul(result, 1, &invRms, &result, 1, vDSP_Length(result.count))
        }
        return result
    }
}
