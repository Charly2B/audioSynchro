import Foundation

// MARK: - VideoMixer
// Applique la piste audio FR sur la vidéo EN avec l'offset calculé via ffmpeg

final class VideoMixer {

    enum MixerError: LocalizedError {
        case ffmpegIntrouvable
        case exportFailed(String)

        var errorDescription: String? {
            switch self {
            case .ffmpegIntrouvable:
                return "ffmpeg introuvable. Installe-le via Homebrew : brew install ffmpeg"
            case .exportFailed(let s):
                return "Export échoué : \(s)"
            }
        }
    }

    /// Crée la vidéo finale : piste vidéo de videoEN + piste audio de audioFR avec offset
    static func mix(
        videoEN: URL,
        audioFR: URL,
        offsetSeconds: Double,
        outputURL: URL,
        progress: @escaping (Double) -> Void
    ) async throws -> URL {

        guard let ffmpeg = ffmpegPath() else { throw MixerError.ffmpegIntrouvable }

        try? FileManager.default.removeItem(at: outputURL)

        // Durée via ffprobe (fonctionne avec MKV contrairement à AVFoundation)
        let duration = ffprobeDuration(url: videoEN)

        var arguments: [String]

        // Arguments communs
        let commonAudio = ["-c:a", "aac", "-ac", "2", "-ar", "48000"]
        let isMKV = outputURL.pathExtension.lowercased() == "mkv"
        let commonVideo = isMKV ? ["-c:v", "copy"] : ["-c:v", "copy", "-tag:v", "hvc1"]

        if offsetSeconds >= 0 {
            // Audio FR en retard : on le décale avec adelay
            let delayMs = Int(offsetSeconds * 1000)
            arguments = [
                "-i", videoEN.path,
                "-i", audioFR.path,
                "-filter_complex", "[1:a]adelay=\(delayMs)|\(delayMs)[aout]",
                "-map", "0:v:0",
                "-map", "[aout]"
            ] + commonVideo + commonAudio + ["-shortest", "-y", outputURL.path]
        } else {
            // Audio FR en avance : on coupe le début via atrim (plus fiable que -ss input)
            let trimStart = abs(offsetSeconds)
            arguments = [
                "-i", videoEN.path,
                "-i", audioFR.path,
                "-filter_complex", String(format: "[1:a]atrim=start=%.3f,asetpts=PTS-STARTPTS[aout]", trimStart),
                "-map", "0:v:0",
                "-map", "[aout]"
            ] + commonVideo + commonAudio + ["-shortest", "-y", outputURL.path]
        }

        try await runProcess(ffmpeg, arguments: arguments, totalDuration: duration, progress: progress)

        guard FileManager.default.fileExists(atPath: outputURL.path) else {
            throw MixerError.exportFailed("Fichier de sortie introuvable")
        }
        return outputURL
    }

    // MARK: - Helpers

    private static func ffprobeDuration(url: URL) -> Double? {
        let candidates = [
            "/opt/homebrew/bin/ffprobe",
            "/usr/local/bin/ffprobe"
        ]
        guard let ffprobe = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }) else { return nil }
        let process = Process()
        process.executableURL = URL(fileURLWithPath: ffprobe)
        process.arguments = ["-v", "error", "-show_entries", "format=duration",
                             "-of", "default=noprint_wrappers=1:nokey=1", url.path]
        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = FileHandle.nullDevice
        try? process.run()
        process.waitUntilExit()
        let output = String(data: pipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8) ?? ""
        return Double(output.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    private static func ffmpegPath() -> String? {
        let candidates = [
            "/opt/homebrew/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
            "/usr/local/Cellar/ffmpeg/8.0.1/bin/ffmpeg",
            "/usr/bin/ffmpeg"
        ]
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
    }

    private static func runProcess(
        _ executable: String,
        arguments: [String],
        totalDuration: Double?,
        progress: @escaping (Double) -> Void
    ) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            let process = Process()
            process.executableURL = URL(fileURLWithPath: executable)
            process.arguments = arguments
            process.standardOutput = FileHandle.nullDevice

            let stderrPipe = Pipe()
            process.standardError = stderrPipe
            var stderrBuffer = Data()

            // Toujours drainer stderr pour éviter le blocage du pipe
            // + accumuler pour afficher le vrai message d'erreur
            stderrPipe.fileHandleForReading.readabilityHandler = { handle in
                let data = handle.availableData
                guard !data.isEmpty else { return }
                stderrBuffer.append(data)
                guard let total = totalDuration, total > 0 else { return }
                let output = String(data: data, encoding: .utf8) ?? ""
                if let range = output.range(of: #"time=(\d+):(\d+):([\d.]+)"#, options: .regularExpression) {
                    let parts = output[range].dropFirst(5).split(separator: ":")
                    if parts.count == 3,
                       let h = Double(parts[0]), let m = Double(parts[1]), let s = Double(parts[2]) {
                        let elapsed = h * 3600 + m * 60 + s
                        progress(min(elapsed / total, 0.99))
                    }
                }
            }

            process.terminationHandler = { p in
                stderrPipe.fileHandleForReading.readabilityHandler = nil
                let errOutput = String(data: stderrBuffer, encoding: .utf8) ?? ""
                if p.terminationStatus == 0 {
                    progress(1.0)
                    continuation.resume()
                } else {
                    let lines = errOutput.components(separatedBy: "\n").filter { !$0.isEmpty }
                    let detail = lines.suffix(5).joined(separator: " | ")
                    continuation.resume(throwing: NSError(
                        domain: "AudioSync", code: Int(p.terminationStatus),
                        userInfo: [NSLocalizedDescriptionKey: "Export échoué : \(detail)"]
                    ))
                }
            }
            do {
                try process.run()
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}
