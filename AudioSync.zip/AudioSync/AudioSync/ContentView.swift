import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var model = SyncModel()
    @State private var manualOffset: Double = 0
    @State private var showManualAdjust = false

    var body: some View {
        VStack(spacing: 0) {
            toolbar
            Divider()
            leftPanel
            Divider()
            statusBar
        }
        .frame(minWidth: 400, minHeight: 320)
    }

    // MARK: - Toolbar

    var toolbar: some View {
        HStack(spacing: 12) {
            Button("Nouveau") { model.reset() }
                .disabled(model.isProcessing)

            Divider().frame(height: 20)

            Button {
                let frName = model.videoFR?
                    .deletingPathExtension().lastPathComponent ?? "video_synced"
                let panel = NSSavePanel()
                panel.nameFieldStringValue = "\(frName) Synchronisé.mkv"
                panel.allowedContentTypes  = [.init(filenameExtension: "mkv")!, .mpeg4Movie]
                panel.message = "Choisir où sauvegarder la vidéo synchronisée"
                guard panel.runModal() == .OK, let dest = panel.url else { return }
                Task { await model.run(outputURL: dest) }
            } label: {
                HStack(spacing: 6) {
                    if model.isProcessing { ProgressView().scaleEffect(0.7).frame(width: 14) }
                    else { Image(systemName: "wand.and.stars") }
                    Text("Synchroniser automatiquement")
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(model.videoEN == nil || model.videoFR == nil || model.isProcessing)

            Divider().frame(height: 20)

            Button {
                showManualAdjust.toggle()
            } label: {
                Label("Ajustement manuel", systemImage: "slider.horizontal.3")
            }
            .disabled(model.videoEN == nil || model.videoFR == nil)

            Spacer()

            if case .done = model.step {
                Label("Vidéo sauvegardée", systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green)
                    .font(.callout.weight(.medium))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
    }

    // MARK: - Panneau principal

    var leftPanel: some View {
        VStack(spacing: 12) {
            dropZone(title: "Vidéo Anglaise (EN)", subtitle: "Vidéo source — on garde sa piste vidéo",
                     url: model.videoEN, color: .blue) { model.videoEN = $0 }

            dropZone(title: "Vidéo Française (FR)", subtitle: "On prend uniquement son audio",
                     url: model.videoFR, color: .orange) { model.videoFR = $0 }

            if showManualAdjust {
                manualAdjustPanel
            }

            if case .done = model.step {
                if model.offsetSeconds != 0 {
                    HStack(spacing: 6) {
                        Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                        Text(String(format: "Offset : %.3fs — Confiance : %.0f%%",
                                    model.offsetSeconds, model.confidence * 100))
                            .font(.callout)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.top, 4)
                }
            }

            Spacer()
        }
        .padding(14)
        .frame(minWidth: 400)
    }

    // MARK: - Ajustement manuel

    var manualAdjustPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Ajustement manuel").font(.headline)
            HStack {
                Text(String(format: "Offset : %.2f s", manualOffset))
                    .font(.callout.monospacedDigit())
                    .frame(width: 110, alignment: .leading)
                Slider(value: $manualOffset, in: -10...10, step: 0.05)
            }
            HStack(spacing: 8) {
                Button("−0.1s") { manualOffset -= 0.1 }
                Button("−0.5s") { manualOffset -= 0.5 }
                Button("Reset") { manualOffset = 0 }
                Button("+0.5s") { manualOffset += 0.5 }
                Button("+0.1s") { manualOffset += 0.1 }
            }
            .buttonStyle(.bordered)
            .font(.caption)

            Button("Appliquer") {
                let frName = model.videoFR?
                    .deletingPathExtension().lastPathComponent ?? "video_synced"
                let panel = NSSavePanel()
                panel.nameFieldStringValue = "\(frName) Synchronisé.mkv"
                panel.allowedContentTypes  = [.init(filenameExtension: "mkv")!, .mpeg4Movie]
                guard panel.runModal() == .OK, let dest = panel.url else { return }
                Task { await model.applyManualOffset(manualOffset, outputURL: dest) }
            }
            .buttonStyle(.borderedProminent)
            .disabled(model.isProcessing)
        }
        .padding(12)
        .background(.ultraThinMaterial)
        .cornerRadius(10)
    }

    // MARK: - Status bar

    var statusBar: some View {
        HStack(spacing: 10) {
            if model.isProcessing {
                ProgressView(value: model.progress)
                    .frame(width: 120)
            } else if case .done = model.step {
                Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
            } else if case .error = model.step {
                Image(systemName: "xmark.circle.fill").foregroundStyle(.red)
            }
            Text(model.log.isEmpty ? "Importe deux vidéos pour commencer" : model.log)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            Spacer()
            if model.isProcessing {
                Text("\(Int(model.progress * 100))%")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 6)
    }

    // MARK: - Drop zone

    func dropZone(title: String, subtitle: String, url: URL?, color: Color, onDrop: @escaping (URL) -> Void) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(url != nil ? color.opacity(0.08) : Color.primary.opacity(0.04))
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .strokeBorder(url != nil ? color : Color.secondary.opacity(0.3), lineWidth: url != nil ? 1.5 : 1)
                )

            if let url {
                HStack(spacing: 10) {
                    Image(systemName: "film.fill")
                        .foregroundStyle(color)
                        .font(.title2)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(url.lastPathComponent)
                            .font(.callout.weight(.medium))
                            .lineLimit(1)
                        Text(title)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button {
                        if title.contains("EN") { model.videoEN = nil }
                        else { model.videoFR = nil }
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.secondary)
                    }
                    .buttonStyle(.plain)
                }
                .padding(12)
            } else {
                VStack(spacing: 6) {
                    Image(systemName: "arrow.down.circle")
                        .font(.title)
                        .foregroundStyle(color.opacity(0.6))
                    Text(title)
                        .font(.callout.weight(.medium))
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button("Choisir…") {
                        pickVideo(onDrop: onDrop)
                    }
                    .buttonStyle(.bordered)
                    .font(.caption)
                    .padding(.top, 2)
                }
                .padding(16)
            }
        }
        .frame(height: 100)
        .onDrop(of: [.fileURL], isTargeted: nil) { providers in
            providers.first?.loadItem(forTypeIdentifier: "public.file-url") { item, _ in
                if let data = item as? Data, let url = URL(dataRepresentation: data, relativeTo: nil) {
                    DispatchQueue.main.async { onDrop(url) }
                }
            }
            return true
        }
    }

    private func pickVideo(onDrop: @escaping (URL) -> Void) {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.mpeg4Movie, .quickTimeMovie,
                                     .init(filenameExtension: "m4v")!,
                                     .init(filenameExtension: "mkv")!]
        panel.allowsMultipleSelection = false
        if panel.runModal() == .OK, let url = panel.url { onDrop(url) }
    }
}
